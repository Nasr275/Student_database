#include <stdio.h>
#include <stdlib.h>
#include "SDB.h"
#include "STD.h"


void SDB_APP()
{
  int choice;
  do    /**We used a do while loop as declaring an integer always sets it to zero which will case the skipping of a traditional while loop*/
  {
     printf("To add entry, enter 1\n");
     printf("To get used size in database, enter 2\n");
     printf("To read student data, enter 3\n");
     printf("To get the list of all student IDs, enter 4\n");
     printf("To check is ID is existed, enter 5\n");
     printf("To delete student data, enter 6\n");
     printf("To check is database is full, enter 7\n");
     printf("To exit, enter 0\n");
     scanf("%d",&choice);
     SDB_action(choice);
     printf("would you like another service?\n");
  }
  while(choice != 0);
}

void SDB_action(uint8 choice)
{
 uint32 id;
 uint32 count;
 uint32 list[10];  /**A list of integers to store all student IDs with a max limit of 10*/

 switch (choice)
 {
 case 1:
     SDB_AddEntry();
     break;
 case 2:
     printf("%d", SDB_GetUsedSize());
     break;
 case 3:
     printf("Please enter student Id to read entry");
     scanf("%d",id);
     SDB_ReadEntry(id);
     break;
 case 4:
     SDB_GetList(&count, list);
     break;
 case 5:
     SDB_IsIdExist(id);
     break;
 case 6:
     SDB_DeleteEntry(id);
     break;
 case 7:
     SDB_IsFull();
     break;
 case 0 :
     break;
 default:
     printf("Please enter a valid choice\n");
     break;
}
printf("\n");
}
