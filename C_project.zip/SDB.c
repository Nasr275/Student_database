#include "SDB.h"
#include "STD.h"


student students[MAX_STUDENTS]; //array of structs of type student with 10 spot registered in case of max students
uint8 numStudents = 0; //A counter to keep track of the number of students in the school




/**Function to check if the database is full or not*/
bool SDB_IsFull()
{
    return (numStudents >= MAX_STUDENTS); //if the number of students exceed the number of students allowed return True
}


/**Function to get the current size of the database*/
uint8 SDB_GetUsedSize() {
    printf("Getting used size in database\n");
    return numStudents;
}



/**Function to add a new entry in the database*/
bool SDB_AddEntry()
{   /**first we need to check if there is a free space to add a new student*/
    if (SDB_IsFull()) {
        printf("Database is full. Cannot add more students.\n");
        return false;  //exit the function
    }

    student newStudent;

    printf("Enter student ID: ");
    scanf("%u", &newStudent.Student_ID);

    // Check if the ID already exists
    if (SDB_IsIdExist(newStudent.Student_ID)) {
        printf("Student with ID %u already exists in the database.\n", newStudent.Student_ID);
        return false;
    }

    printf("Enter student year: ");
    scanf("%u", &newStudent.Student_year);    // %u is used for unsigned integers


    for (uint32 i = 0; i < 3; i++) {
        printf("Enter course %d ID: ", i + 1);
        scanf("%u", &newStudent.courseIDs[i]);
        printf("Enter course %d grade: ", i + 1);
        scanf("%u", &newStudent.courseGrades[i]);
    }

    students[numStudents] = newStudent;
    numStudents++;

    printf("Student added successfully.\n");
    return true;
}

/**Function to deleting an entry in our database*/
void SDB_DeleteEntry(uint32 id) {
    for (uint32 i = 0; i < numStudents; i++) {
        if (students[i].Student_ID == id) {
            // Shift all elements after the deleted student to the left
            for (uint32 j = i; j < numStudents - 1; j++) {
                students[j] = students[j + 1];
            }
            numStudents--;
            printf("Student with ID %u deleted successfully.\n", id);
            return;
        }
    }
    printf("Student with ID %u not found in the database.\n", id);
}

bool SDB_ReadEntry(uint32 id) {
    for (int i = 0; i < numStudents; i++) {
        if (students[i].Student_ID == id) {
            printf("Student ID: %u\n", students[i].Student_ID);
            printf("Year: %hhu\n", students[i].Student_year);
            for (int j = 0; j < 3; j++) {
                printf("Course %d ID: %u\n", j + 1, students[i].courseIDs[j]);
                printf("Course %d grade: %u\n", j + 1, students[i].courseGrades[j]);
            }
            return true;
        }
    }
    printf("Student with ID %u not found in the database.\n", id);
    return false;
}

void SDB_GetList(uint8 *count, uint32 *list) {
    *count = numStudents;
    for (uint32 i = 0; i < numStudents; i++) {
        list[i] = students[i].Student_ID;
    }
    printf("Number of IDs: %u\n", count);
    printf("List of IDs: ");
    for (int i = 0; i < count; i++) {
        printf("%u ", list[i]);
    }
    printf("\n");
}

bool SDB_IsIdExist(uint32 id) {
    for (int i = 0; i < numStudents; i++) {
        if (students[i].Student_ID == id) {
            return true;
        }
    }
    return false;
}
